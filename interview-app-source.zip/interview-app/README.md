# AI 면접 코치 (대충 버전 소스)

캔버스 디자인(홈 · 면접관 성향 · 피드백 방식 · 면접 진행 · 리포트 · 퀘스트 · 속마음 · 돌발 카드 · 보스전 · 자소서 · 기업 정보)을 자바로 옮긴 뼈대예요.

```
server/   Spring Boot 3 (Java 17) — Claude API 호출, 퀘스트/포인트/기업 후기 API
android/  안드로이드 앱 (Java) — 화면, 카메라 녹화, 음성 질문(TTS), 받아쓰기, 시선 측정
```

## 왜 서버가 따로 있나요?
Claude API 키를 앱에 넣으면 누구나 꺼내 쓸 수 있어요. 키는 서버 환경변수에만 두고, 앱은 서버만 불러요.

## 서버 실행
```bash
cd server
export ANTHROPIC_API_KEY=sk-ant-...
mvn spring-boot:run          # http://localhost:8080
```

| 기능 | API | AI 사용 |
|---|---|---|
| 면접관 다음 질문 (성향·꼬리질문·자소서/기업 질문 반영) | `POST /api/interview/next-question` | O |
| 면접 리포트 + 면접관 속마음 타임라인 | `POST /api/interview/report` | O |
| 실시간 팁 (시선/말 속도/습관어) | `POST /api/interview/live-tip` | X (규칙, 빠르게) |
| 돌발 상황 카드 | `GET /api/interview/curveball` | X |
| 자소서 문장별 피드백 | `POST /api/cover-letter/feedback` | O |
| 자소서 기반 예상 질문 | `POST /api/cover-letter/questions` | O |
| 채용공고 분석 | `POST /api/job-post/analyze` | O |
| 프로필·데일리 퀘스트 / 이벤트 / 보상 받기 | `GET /api/users/{id}/profile`, `POST .../events`, `POST .../quests/{q}/claim` | X |
| 주말 보스전 결과 | `POST /api/users/{id}/boss` | X |
| 기업 후기 올리기(포인트) / 조회 / 100P 열람 | `POST /api/companies/{c}/reviews`, `GET /api/companies/{c}`, `POST .../unlock` | X |

AI 응답은 구조화 출력(JSON 스키마 = `Dtos` 레코드)으로 받아서 파싱 실패가 없어요.
모델은 `claude-opus-5-5`, 안전 분류기 거절 시 서버 측 자동 폴백(`fallbacks: "default"`)을 켜 두었어요.

## 앱 실행
Android Studio 로 `android/` 폴더를 열고 실행. 에뮬레이터는 `10.0.2.2:8080` 으로 PC 서버에 붙어요
(실기기는 `app/build.gradle` 의 `API_BASE` 를 PC IP 로).

- 면접관 장면: `res/drawable/interviewer_mentor.png` 처럼 성향별 일러스트를 넣으면 자동으로 바뀜
- 녹화 영상은 기기 갤러리(MediaStore)에 저장, 서버로는 보내지 않음. 시선·자세는 ML Kit 로 기기 안에서 계산

## 대충 버전이라 아직 안 된 것
- 저장소가 메모리라 서버를 끄면 데이터가 사라짐 → DB(JPA) 로 교체
- 로그인 없음 (기기별 익명 ID)
- 후기 인증은 캡처만 있으면 통과 → 검수 큐 + 개인정보 마스킹 필요
- 영상은 무음 녹화 (`RECORD_AUDIO_IN_VIDEO`): 많은 기기에서 녹화와 받아쓰기가 마이크를 동시에 못 씀
- 보스전 전용 세션, 주간 도전 횟수 초기화, 임원형 잠금, 돌발 빈도 설정 UI
