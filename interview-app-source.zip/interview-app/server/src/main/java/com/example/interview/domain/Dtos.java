package com.example.interview.domain;

import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import java.util.List;

/** API 요청/응답 모델 모음. AI 응답 타입은 Claude 구조화 출력 스키마로도 쓰인다. */
public final class Dtos {
    private Dtos() {}

    public enum FeedbackMode { LIVE, AFTER }

    // ---------- 면접 진행 ----------
    public record Turn(String question, String answer, int startSec, int endSec) {}

    public record NextQuestionRequest(
            Persona persona,
            String job,
            int questionCount,
            List<Turn> history,
            /** 자소서/공고/기업 후기에서 뽑은 질문이 있으면 우선 사용 */
            List<String> seedQuestions,
            /** 기업 후기에서 얻은 면접 분위기·특징 */
            String companyContext) {}

    public record NextQuestion(
            @JsonPropertyDescription("면접관이 말할 다음 질문 한두 문장") String question,
            @JsonPropertyDescription("직전 답변에 대한 꼬리질문이면 true") boolean followUp,
            @JsonPropertyDescription("정해진 질문 수를 채워 면접을 끝내야 하면 true") boolean done) {}

    /** 앱(온디바이스)에서 측정한 태도 지표. 영상 자체는 서버로 보내지 않는다. */
    public record AttitudeMetrics(
            double gazeAwayRatio,   // 화면을 보지 않은 시간 비율 0~1
            int fillerCount,        // "음", "어" 같은 습관어 횟수
            double wordsPerMinute,  // 말 속도
            double postureScore,    // 0~100, 어깨 기울기/움직임 기반
            List<Integer> gazeAwaySeconds) {}

    public record ReportRequest(Persona persona, FeedbackMode mode, List<Turn> turns, AttitudeMetrics metrics) {}

    public record Scores(int gaze, int posture, int pace, int structure, int filler) {}

    public record QuestionFeedback(int index, String good, String fix) {}

    public record InnerVoice(
            @JsonPropertyDescription("mm:ss") String time,
            @JsonPropertyDescription("그 순간 면접관의 속마음 한 문장") String thought,
            @JsonPropertyDescription("호감/의심/지루함/강한 호감 중 하나") String mood,
            @JsonPropertyDescription("이런 생각이 든 이유") String cause) {}

    public record Report(int overall, Scores scores, List<QuestionFeedback> perQuestion, List<InnerVoice> innerVoice) {}

    /** 실시간 모드: 몇 초마다 앱이 보내는 짧은 신호 → 즉시 띄울 한 줄 피드백 */
    public record LiveSignal(double gazeAwayRatio, int fillerCount, double wordsPerMinute) {}

    public record LiveTip(String gaze, String pace, String filler) {}

    // ---------- 자소서 ----------
    public record CoverLetterRequest(String question, String text, String jobPost) {}

    public record CoverLetterScores(int specificity, int jobFit, int readability, int uniqueness) {}

    public record SentenceFeedback(
            @JsonPropertyDescription("원문 문장 그대로") String text,
            @JsonPropertyDescription("FIX 또는 GOOD") String kind,
            String title,
            String why,
            @JsonPropertyDescription("FIX일 때만 고친 문장, GOOD이면 빈 문자열") String rewrite) {}

    public record CoverLetterFeedback(CoverLetterScores scores, List<SentenceFeedback> sentences) {}

    public record CoverQuestionsRequest(String coverLetter, String jobPost) {}

    public record PredictedQuestion(
            @JsonPropertyDescription("경험 검증 / 꼬리질문 / 약점 공략 중 하나") String type,
            @JsonPropertyDescription("근거가 된 자소서 문장 원문") String quote,
            String question,
            String guide,
            boolean priority) {}

    public record PredictedQuestions(List<PredictedQuestion> questions) {}

    // ---------- 채용공고 ----------
    public record JobPostRequest(String jobPost, String coverLetter) {}

    public record Keyword(String label, boolean matched) {}

    public record JobQuestion(String question, String basis) {}

    public record JobPostAnalysis(List<Keyword> keywords, List<String> gaps, List<JobQuestion> questions) {}
}
