package com.example.interview.quest;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** 사용자 상태 저장소. 대충 버전이라 메모리에 둔다 → 실서비스는 DB(JPA 등)로 교체. */
@Component
public class UserStore {

    public static class UserState {
        public int xp;
        public int points;
        public int streak;
        public int bestStreak;
        public LocalDate lastPracticeDate;
        public LocalDate questDate = LocalDate.now();
        public final Map<String, Integer> questProgress = new HashMap<>();
        public final Set<String> claimedQuests = new HashSet<>();
        public final Set<String> unlockedReviews = new HashSet<>();
        public final Set<String> unlockedPersonas = new HashSet<>();
        public int bossAttemptsThisWeek;
        public int bossBest;

        public int level() {
            return 1 + xp / 500;
        }
    }

    private final Map<String, UserState> users = new ConcurrentHashMap<>();

    public UserState get(String userId) {
        UserState s = users.computeIfAbsent(userId, id -> new UserState());
        // 날짜가 바뀌면 데일리 퀘스트 초기화
        if (!LocalDate.now().equals(s.questDate)) {
            s.questDate = LocalDate.now();
            s.questProgress.clear();
            s.claimedQuests.clear();
        }
        return s;
    }

    /** 오늘 연습했음을 기록하고 연속 일수를 갱신 */
    public void markPracticed(UserState s) {
        LocalDate today = LocalDate.now();
        if (today.equals(s.lastPracticeDate)) return;
        s.streak = today.minusDays(1).equals(s.lastPracticeDate) ? s.streak + 1 : 1;
        s.bestStreak = Math.max(s.bestStreak, s.streak);
        s.lastPracticeDate = today;
    }
}
