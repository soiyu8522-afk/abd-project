package com.example.interview.api;

import com.example.interview.ai.ClaudeService;
import com.example.interview.domain.Dtos.*;
import com.example.interview.domain.Persona;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/interview")
public class InterviewController {

    private final ClaudeService claude;
    private final Random random = new Random();

    public InterviewController(ClaudeService claude) {
        this.claude = claude;
    }

    /** 면접관의 다음 질문. 앱은 받은 question 을 TextToSpeech 로 읽어 준다. */
    @PostMapping("/next-question")
    public NextQuestion nextQuestion(@RequestBody NextQuestionRequest req) {
        String system = req.persona().prompt + """

                지금은 %s 직무 모의 면접입니다. 총 %d개의 메인 질문을 합니다.
                한 번에 질문 하나만, 실제 면접관이 말하듯 한국어 구어체로 짧게 말하세요.
                직전 답변이 모호하면 꼬리질문을 해도 됩니다(꼬리질문은 메인 질문 수에 세지 않음).
                """.formatted(req.job(), req.questionCount());

        StringBuilder user = new StringBuilder();
        if (req.companyContext() != null && !req.companyContext().isBlank()) {
            user.append("[이 회사 면접 후기 요약]\n").append(req.companyContext()).append("\n\n");
        }
        if (req.seedQuestions() != null && !req.seedQuestions().isEmpty()) {
            user.append("[우선 물어볼 질문 후보]\n- ")
                .append(String.join("\n- ", req.seedQuestions())).append("\n\n");
        }
        user.append("[지금까지의 대화]\n").append(transcript(req.history()));
        user.append("\n다음 질문을 하세요.");

        return claude.askStructured(system, user.toString(), NextQuestion.class);
    }

    /** 면접 종료 후 리포트 + 면접관 속마음 타임라인. */
    @PostMapping("/report")
    public Report report(@RequestBody ReportRequest req) {
        String system = """
                당신은 면접 코치입니다. 면접 대화 기록과 앱이 측정한 태도 지표를 보고 피드백합니다.
                점수는 0~100 정수. 문항별로 잘한 점 하나, 고칠 점 하나를 구체적으로 씁니다.
                innerVoice 에는 면접관(%s)이 실제로 했을 법한 속마음을 시간 순으로 4~6개 씁니다.
                지표에 없는 사실을 지어내지 마세요.
                """.formatted(req.persona().label);

        AttitudeMetrics m = req.metrics();
        String user = """
                [태도 지표] 시선 이탈 비율 %.2f, 습관어 %d회, 말 속도 %.0f 단어/분, 자세 점수 %.0f, 시선 이탈 시점(초) %s
                [대화]
                %s
                """.formatted(m.gazeAwayRatio(), m.fillerCount(), m.wordsPerMinute(), m.postureScore(),
                m.gazeAwaySeconds(), transcript(req.turns()));

        return claude.askStructured(system, user, Report.class);
    }

    /**
     * 실시간 피드백. 몇 초마다 호출되므로 AI를 부르지 않고 규칙으로 바로 답한다.
     * (속도가 중요해서. 필요하면 온디바이스에서 같은 규칙을 돌려도 된다)
     */
    @PostMapping("/live-tip")
    public LiveTip liveTip(@RequestBody LiveSignal s) {
        String gaze = s.gazeAwayRatio() > 0.3 ? "카메라를 봐 주세요" : "좋아요";
        String pace = s.wordsPerMinute() > 170 ? "조금 천천히" : s.wordsPerMinute() < 90 ? "조금 더 또렷하게" : "적당해요";
        String filler = s.fillerCount() >= 3 ? "“음…” " + s.fillerCount() + "회" : "좋아요";
        return new LiveTip(gaze, pace, filler);
    }

    /** 돌발 상황 카드 (돌발 빈도: NONE / SOMETIMES / OFTEN 은 앱에서 확률로 처리) */
    @GetMapping("/curveball")
    public Curveball curveball() {
        return CURVEBALLS.get(random.nextInt(CURVEBALLS.size()));
    }

    public record Curveball(String title, String description, String tip, int seconds, int panelSize) {}

    private static final List<Curveball> CURVEBALLS = List.of(
            new Curveball("면접관 2명이 갑자기 들어왔어요", "이제부터 3:1 면접이에요.", "질문한 사람을 보고 답하고, 마무리는 전원을 한 번씩 보세요.", 30, 3),
            new Curveball("“이 질문은 영어로 답해 주세요.”", "방금 질문을 영어로 다시 답해야 해요.", "결론 → 근거 하나 → 마무리, 세 문장이면 충분해요.", 45, 1),
            new Curveball("“시간이 없어서요. 20초만 주세요.”", "답변을 줄여 달라고 해요.", "첫 문장에 결론, 숫자 하나로 뒷받침.", 20, 1),
            new Curveball("면접관이 10초 동안 말이 없어요", "침묵이 이어져요.", "덧붙이지 말고 “이상입니다”로 정리하고 기다리세요.", 10, 1),
            new Curveball("“앞에서 한 말과 다른데요?”", "모순을 지적받았어요.", "차이를 인정하고 맥락을 한 문장으로 설명하세요.", 30, 1));

    private static String transcript(List<Turn> turns) {
        if (turns == null || turns.isEmpty()) return "(아직 없음)\n";
        return turns.stream()
                .map(t -> "Q: " + t.question() + "\nA(" + t.startSec() + "~" + t.endSec() + "초): " + t.answer())
                .collect(Collectors.joining("\n")) + "\n";
    }

    @ExceptionHandler(ClaudeService.AiRefusedException.class)
    @ResponseStatus(org.springframework.http.HttpStatus.UNPROCESSABLE_ENTITY)
    public String refused(ClaudeService.AiRefusedException e) {
        return e.getMessage();
    }
}
