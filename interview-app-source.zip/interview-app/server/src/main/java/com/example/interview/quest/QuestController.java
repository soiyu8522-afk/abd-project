package com.example.interview.quest;

import com.example.interview.domain.Persona;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api")
public class QuestController {

    /** 앱이 보내는 이벤트 종류 */
    public enum EventType { INTRO_RECORDED, INTERVIEW_DONE, ANSWERED, GAZE_SCORE }

    public record QuestDef(String id, String title, int goal, int xp) {}

    private static final List<QuestDef> DAILY = List.of(
            new QuestDef("intro", "1분 자기소개 녹화하기", 1, 30),
            new QuestDef("interview", "모의 면접 1회 완료하기", 1, 50),
            new QuestDef("pressure", "압박형 면접관과 3문항 답변", 3, 50),
            new QuestDef("gaze", "시선 처리 80점 이상 받기", 1, 40));

    public record QuestView(String id, String title, int done, int goal, int xp, boolean claimed) {}

    public record Profile(int level, int xp, int points, int streak, int bestStreak, List<QuestView> quests) {}

    public record Event(EventType type, Persona persona, Integer value) {}

    public record BossAttempt(int persuasion) {}

    public record BossResult(boolean cleared, int best, int attemptsLeft, List<String> rewards) {}

    private static final int BOSS_PASS = 80;
    private static final int BOSS_WEEKLY_ATTEMPTS = 3;

    private final UserStore store;

    public QuestController(UserStore store) {
        this.store = store;
    }

    @GetMapping("/users/{userId}/profile")
    public Profile profile(@PathVariable String userId) {
        UserStore.UserState s = store.get(userId);
        List<QuestView> quests = DAILY.stream()
                .map(q -> new QuestView(q.id(), q.title(), Math.min(s.questProgress.getOrDefault(q.id(), 0), q.goal()),
                        q.goal(), q.xp(), s.claimedQuests.contains(q.id())))
                .toList();
        return new Profile(s.level(), s.xp, s.points, s.streak, s.bestStreak, quests);
    }

    /** 면접 화면/리포트에서 일어난 일을 보내면 퀘스트 진행도가 오른다. */
    @PostMapping("/users/{userId}/events")
    public Profile event(@PathVariable String userId, @RequestBody Event e) {
        UserStore.UserState s = store.get(userId);
        store.markPracticed(s);
        switch (e.type()) {
            case INTRO_RECORDED -> s.questProgress.merge("intro", 1, Integer::sum);
            case INTERVIEW_DONE -> s.questProgress.merge("interview", 1, Integer::sum);
            case ANSWERED -> {
                if (e.persona() == Persona.PRESSURE) s.questProgress.merge("pressure", 1, Integer::sum);
            }
            case GAZE_SCORE -> {
                if (e.value() != null && e.value() >= 80) s.questProgress.merge("gaze", 1, Integer::sum);
            }
        }
        return profile(userId);
    }

    @PostMapping("/users/{userId}/quests/{questId}/claim")
    public Profile claim(@PathVariable String userId, @PathVariable String questId) {
        UserStore.UserState s = store.get(userId);
        QuestDef q = DAILY.stream().filter(d -> d.id().equals(questId)).findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        if (s.questProgress.getOrDefault(questId, 0) < q.goal() || !s.claimedQuests.add(questId)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "아직 완료하지 않았거나 이미 받은 보상이에요");
        }
        s.xp += q.xp();
        return profile(userId);
    }

    /** 주말 보스전: 설득 게이지(리포트 종합 점수)가 80 이상이면 클리어 */
    @PostMapping("/users/{userId}/boss")
    public BossResult boss(@PathVariable String userId, @RequestBody BossAttempt a) {
        UserStore.UserState s = store.get(userId);
        if (s.bossAttemptsThisWeek >= BOSS_WEEKLY_ATTEMPTS) {
            throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS, "이번 주 도전 횟수를 다 썼어요");
        }
        s.bossAttemptsThisWeek++;  // TODO: 매주 월요일 초기화 스케줄러
        boolean firstClear = a.persuasion() >= BOSS_PASS && s.bossBest < BOSS_PASS;
        s.bossBest = Math.max(s.bossBest, a.persuasion());
        List<String> rewards = List.of();
        if (firstClear) {
            s.xp += 500;
            s.unlockedPersonas.add(Persona.EXECUTIVE.name());
            rewards = List.of("최종 면접 통과 배지", "새 면접관: " + Persona.EXECUTIVE.label, "+500 XP");
        }
        return new BossResult(a.persuasion() >= BOSS_PASS, s.bossBest, BOSS_WEEKLY_ATTEMPTS - s.bossAttemptsThisWeek, rewards);
    }
}
