package com.example.interview.api;

import com.example.interview.ai.ClaudeService;
import com.example.interview.domain.Dtos.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class CoverLetterController {

    private final ClaudeService claude;

    public CoverLetterController(ClaudeService claude) {
        this.claude = claude;
    }

    /** 자기소개서 문장 단위 피드백 (앱에서 FIX=주황, GOOD=파랑 하이라이트) */
    @PostMapping("/cover-letter/feedback")
    public CoverLetterFeedback feedback(@RequestBody CoverLetterRequest req) {
        String system = """
                당신은 채용 담당자 출신 자기소개서 코치입니다.
                자소서를 문장 단위로 나눠 고칠 문장(FIX)과 살릴 문장(GOOD)을 고르세요. 평범한 문장은 넣지 않습니다.
                FIX 의 rewrite 는 지원자가 실제로 쓴 사실 범위 안에서 고치고, 숫자가 필요하면 [수치]처럼 빈칸으로 둡니다.
                text 필드는 원문 문장을 한 글자도 바꾸지 말고 그대로 넣으세요(앱이 원문에서 위치를 찾습니다).
                """;
        String user = "[문항] " + req.question() + "\n[자소서]\n" + req.text()
                + (req.jobPost() == null ? "" : "\n[지원 공고]\n" + req.jobPost());
        return claude.askStructured(system, user, CoverLetterFeedback.class);
    }

    /** 자소서 기반 예상 질문 */
    @PostMapping("/cover-letter/questions")
    public PredictedQuestions questions(@RequestBody CoverQuestionsRequest req) {
        String system = """
                당신은 면접관입니다. 아래 자기소개서를 읽고 면접에서 실제로 파고들 질문을 6~8개 만드세요.
                type: 경험 검증(쓴 내용이 사실인지 확인), 꼬리질문(기술/판단의 깊이), 약점 공략(빠진 경험·모순).
                quote 에는 근거가 된 자소서 문장 원문을, guide 에는 답변 방향을 2문장 이내로 씁니다.
                가장 먼저 연습해야 할 2개만 priority=true.
                """;
        String user = "[자소서]\n" + req.coverLetter()
                + (req.jobPost() == null ? "" : "\n[지원 공고]\n" + req.jobPost());
        return claude.askStructured(system, user, PredictedQuestions.class);
    }

    /** 채용공고 분석: 핵심 역량, 자소서와의 빈틈, 예상 질문 */
    @PostMapping("/job-post/analyze")
    public JobPostAnalysis analyzeJobPost(@RequestBody JobPostRequest req) {
        String system = """
                채용공고에서 핵심 역량 키워드를 5~8개 뽑고, 자소서에 그 경험이 있으면 matched=true 로 표시하세요.
                gaps 에는 자소서에 없는 우대/필수 역량을 씁니다. questions 는 공고 문구를 근거(basis)로 4~6개.
                """;
        String user = "[공고]\n" + req.jobPost() + "\n[자소서]\n" + (req.coverLetter() == null ? "(없음)" : req.coverLetter());
        return claude.askStructured(system, user, JobPostAnalysis.class);
    }
}
