package com.example.interview.ai;

import com.anthropic.client.AnthropicClient;
import com.anthropic.client.okhttp.AnthropicOkHttpClient;
import com.anthropic.core.JsonValue;
import com.anthropic.models.messages.Message;
import com.anthropic.models.messages.MessageCreateParams;
import com.anthropic.models.messages.StopReason;
import com.anthropic.models.messages.StructuredMessage;
import com.anthropic.models.messages.StructuredMessageCreateParams;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

/**
 * Claude 호출을 한곳에 모은 서비스.
 * API 키는 서버 환경변수(ANTHROPIC_API_KEY)에서만 읽는다. 모바일 앱에 키를 넣으면 유출된다.
 */
@Service
public class ClaudeService {

    private static final String MODEL = "claude-opus-5-5";

    private final AnthropicClient client = AnthropicOkHttpClient.fromEnv();

    /** 응답을 지정한 레코드 타입(JSON 스키마)으로 받는다. */
    public <T> T askStructured(String system, String user, Class<T> type) {
        StructuredMessageCreateParams<T> params = MessageCreateParams.builder()
                .model(MODEL)
                .maxTokens(16000L)
                .system(system)
                .addUserMessage(user)
                // 안전 분류기가 거절하면 서버 측에서 다른 모델로 자동 재시도
                .putAdditionalHeader("anthropic-beta", "server-side-fallback-2026-07-01")
                .putAdditionalBodyProperty("fallbacks", JsonValue.from("default"))
                .outputConfig(type)
                .build();

        StructuredMessage<T> res = client.messages().create(params);
        if (res.stopReason().filter(StopReason.REFUSAL::equals).isPresent()) {
            throw new AiRefusedException();
        }
        return res.content().stream()
                .flatMap(block -> block.text().stream())
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("빈 응답"))
                .text();
    }

    /** 자유 텍스트 응답 (면접관 대사 등). */
    public String askText(String system, String user) {
        MessageCreateParams params = MessageCreateParams.builder()
                .model(MODEL)
                .maxTokens(16000L)
                .system(system)
                .addUserMessage(user)
                .putAdditionalHeader("anthropic-beta", "server-side-fallback-2026-07-01")
                .putAdditionalBodyProperty("fallbacks", JsonValue.from("default"))
                .build();

        Message res = client.messages().create(params);
        if (res.stopReason().filter(StopReason.REFUSAL::equals).isPresent()) {
            throw new AiRefusedException();
        }
        return res.content().stream()
                .flatMap(block -> block.text().stream())
                .map(t -> t.text())
                .collect(Collectors.joining());
    }

    public static class AiRefusedException extends RuntimeException {
        public AiRefusedException() {
            super("AI가 이 요청을 처리하지 않았어요. 내용을 바꿔 다시 시도해 주세요.");
        }
    }
}
