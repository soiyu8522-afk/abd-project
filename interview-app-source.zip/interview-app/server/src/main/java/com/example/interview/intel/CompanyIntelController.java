package com.example.interview.intel;

import com.example.interview.quest.UserStore;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * 기업별 면접 후기. 면접을 본 사람이 정보를 올리면 포인트를 받고,
 * 다른 사람의 상세 후기는 포인트로 연다.
 */
@RestController
@RequestMapping("/api/companies")
public class CompanyIntelController {

    static final int BASE_POINTS = 50;
    static final int PER_QUESTION_POINTS = 10;
    static final int VERIFIED_POINTS = 100;
    static final int UNLOCK_COST = 100;

    public record ReviewRequest(String userId, String role, String period, List<String> stages,
                                List<String> questions, String mood, String result, String detail,
                                /** 면접 안내 메일/문자 캡처. 서버에서 이름·연락처 마스킹 후 검수, 검수 끝나면 삭제 */
                                String proofImageBase64) {}

    public record Review(String id, String company, String authorId, String role, String period,
                         List<String> stages, List<String> questions, String mood, String result,
                         String detail, boolean verified) {}

    public record PointResult(int earned, int balance) {}

    public record QuestionStat(String question, long count) {}

    public record ReviewPreview(String id, String role, String period, String result, boolean verified,
                                String detail, boolean locked) {}

    public record CompanySummary(String company, int reviewCount, List<String> stages,
                                 List<QuestionStat> questions, List<String> moods, List<ReviewPreview> reviews) {}

    private final Map<String, List<Review>> reviews = new ConcurrentHashMap<>();
    private final UserStore store;

    public CompanyIntelController(UserStore store) {
        this.store = store;
    }

    @PostMapping("/{company}/reviews")
    public PointResult submit(@PathVariable String company, @RequestBody ReviewRequest req) {
        List<Review> list = reviews.computeIfAbsent(company, c -> new CopyOnWriteArrayList<>());
        if (list.stream().anyMatch(r -> r.authorId().equals(req.userId()))) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "이 회사 후기는 이미 올렸어요");
        }
        // 대충 버전: 캡처가 있으면 인증된 것으로 처리. 실서비스는 검수 큐 → 승인 시 VERIFIED_POINTS 지급
        boolean verified = req.proofImageBase64() != null && !req.proofImageBase64().isBlank();
        List<String> qs = req.questions() == null ? List.of() : req.questions();
        list.add(new Review(UUID.randomUUID().toString(), company, req.userId(), req.role(), req.period(),
                req.stages(), qs, req.mood(), req.result(), req.detail(), verified));

        int earned = BASE_POINTS + qs.size() * PER_QUESTION_POINTS + (verified ? VERIFIED_POINTS : 0);
        UserStore.UserState s = store.get(req.userId());
        s.points += earned;
        return new PointResult(earned, s.points);
    }

    @GetMapping("/{company}")
    public CompanySummary summary(@PathVariable String company, @RequestParam String userId) {
        List<Review> list = reviews.getOrDefault(company, List.of());
        UserStore.UserState s = store.get(userId);

        List<String> stages = list.stream().flatMap(r -> r.stages().stream()).distinct().toList();
        List<QuestionStat> questions = list.stream()
                .flatMap(r -> r.questions().stream())
                .collect(Collectors.groupingBy(q -> q, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .map(e -> new QuestionStat(e.getKey(), e.getValue()))
                .toList();
        List<String> moods = list.stream().map(Review::mood).filter(Objects::nonNull).distinct().toList();
        List<ReviewPreview> previews = list.stream().map(r -> {
            boolean open = r.authorId().equals(userId) || s.unlockedReviews.contains(r.id());
            String detail = open ? r.detail() : teaser(r.detail());
            return new ReviewPreview(r.id(), r.role(), r.period(), r.result(), r.verified(), detail, !open);
        }).toList();

        return new CompanySummary(company, list.size(), stages, questions, moods, previews);
    }

    @PostMapping("/{company}/reviews/{reviewId}/unlock")
    public PointResult unlock(@PathVariable String company, @PathVariable String reviewId, @RequestParam String userId) {
        UserStore.UserState s = store.get(userId);
        if (s.unlockedReviews.contains(reviewId)) return new PointResult(0, s.points);
        if (s.points < UNLOCK_COST) {
            throw new ResponseStatusException(HttpStatus.PAYMENT_REQUIRED, "포인트가 부족해요. 후기를 공유하고 포인트를 받아 보세요");
        }
        s.points -= UNLOCK_COST;
        s.unlockedReviews.add(reviewId);
        return new PointResult(-UNLOCK_COST, s.points);
    }

    /** 면접관 프롬프트에 넣을 기업 정보 요약 (InterviewController 의 companyContext 로 사용) */
    public record CompanyContext(String context) {}

    @GetMapping("/{company}/context")
    public CompanyContext context(@PathVariable String company) {
        CompanySummary sum = summary(company, "_system");
        return new CompanyContext("단계: " + String.join(" → ", sum.stages())
                + "\n분위기: " + String.join(", ", sum.moods())
                + "\n자주 나온 질문: " + sum.questions().stream().limit(5).map(QuestionStat::question)
                .collect(Collectors.joining(" / ")));
    }

    private static String teaser(String detail) {
        if (detail == null) return "";
        return detail.length() <= 40 ? "…" : detail.substring(0, 40) + "…";
    }
}
