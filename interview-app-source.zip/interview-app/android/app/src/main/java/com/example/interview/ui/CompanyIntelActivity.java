package com.example.interview.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.interview.interview.InterviewActivity;
import com.example.interview.net.Api;
import com.example.interview.net.Models;

import java.io.InputStream;
import java.util.Arrays;

/**
 * 기업별 면접 정보.
 * - 그 회사 면접을 본 사람들의 후기(단계, 실제 질문, 분위기)를 모아 보여준다
 * - 후기를 공유하면 포인트 (기본 50 + 질문당 10 + 참여 인증 100)
 * - 다른 사람의 상세 후기는 100P 로 연다
 * - 후기 요약을 면접관 프롬프트에 넣어 '이 회사 면접관'으로 연습
 */
public class CompanyIntelActivity extends AppCompatActivity {

    private EditText companyInput;
    private LinearLayout result;
    private String proofBase64;
    private TextView proofLabel;

    private final ActivityResultLauncher<PickVisualMediaRequest> pickProof =
            registerForActivityResult(new ActivityResultContracts.PickVisualMedia(), this::onProofPicked);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);
        Ui.title(this, root, "기업 면접 정보");
        companyInput = new EditText(this);
        companyInput.setHint("회사 이름");
        root.addView(companyInput);
        Ui.button(this, root, "검색", Ui.INK, v -> load());
        Ui.button(this, root, "면접 후기 쓰고 포인트 받기", Ui.ORANGE, v -> showShareForm());
        result = Ui.column(this);
        root.addView(result);
    }

    private String company() {
        return companyInput.getText().toString().trim();
    }

    private void load() {
        if (company().isEmpty()) return;
        Api.call(this, Api.get().company(company(), Api.userId(this)), this::bind);
    }

    private void bind(Models.CompanySummary s) {
        result.removeAllViews();
        Ui.heading(this, result, s.company + " · 면접 후기 " + s.reviewCount + "개");

        LinearLayout process = Ui.card(this, result);
        Ui.heading(this, process, "면접 과정");
        Ui.text(this, process, String.join(" → ", s.stages), 14, Ui.INK);
        Ui.text(this, process, "분위기: " + String.join(", ", s.moods), 13, Ui.MUTED);

        LinearLayout qs = Ui.card(this, result);
        Ui.heading(this, qs, "실제로 나온 질문");
        for (Models.QuestionStat q : s.questions) {
            Ui.text(this, qs, "• " + q.question + "  (" + q.count + "명이 받음)", 14, Ui.INK);
        }

        for (Models.ReviewPreview r : s.reviews) {
            LinearLayout c = Ui.card(this, result);
            Ui.text(this, c, (r.verified ? "[인증 " + r.result + "] " : "") + r.role + " · " + (r.period == null ? "" : r.period), 12, Ui.MUTED);
            Ui.text(this, c, r.detail, 14, Ui.INK);
            if (r.locked) {
                Ui.button(this, c, "100P로 전체 후기 열기", Ui.ORANGE,
                        v -> Api.call(this, Api.get().unlock(s.company, r.id, Api.userId(this)), p -> load()));
            }
        }

        Ui.button(this, result, "이 회사 면접관으로 연습하기", Ui.BLUE, v -> {
            Intent i = new Intent(this, InterviewerSelectActivity.class);
            i.putExtra(InterviewActivity.EXTRA_COMPANY, s.company);
            startActivity(i);
        });
    }

    // ---------- 후기 공유 ----------

    private void showShareForm() {
        if (company().isEmpty()) {
            Toast.makeText(this, "회사 이름을 먼저 입력해 주세요", Toast.LENGTH_SHORT).show();
            return;
        }
        proofBase64 = null;
        LinearLayout form = Ui.column(this);
        int p = Ui.dp(this, 20);
        form.setPadding(p, 0, p, 0);
        EditText role = field(form, "직무 (예: 백엔드)");
        EditText period = field(form, "면접 시기 (예: 2026 하반기)");
        EditText stages = field(form, "거친 단계 (쉼표로: 서류, 코딩 테스트, 1차 실무)");
        EditText questions = field(form, "받은 질문 (한 줄에 하나, 질문당 +10P)");
        questions.setMinLines(3);
        EditText mood = field(form, "분위기 (예: 편안함, 꼬리질문 많음)");
        EditText resultField = field(form, "결과 (합격 / 불합격 / 결과 대기)");
        EditText detail = field(form, "상세 후기 (다른 사람은 100P로 열람)");
        detail.setMinLines(3);
        CheckBox verify = new CheckBox(this);
        verify.setText("면접 참여 인증하기 +100P (안내 메일/문자 캡처)");
        verify.setOnCheckedChangeListener((b, checked) -> {
            if (checked) pickProof.launch(new PickVisualMediaRequest.Builder()
                    .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE).build());
            else proofBase64 = null;
        });
        form.addView(verify);
        proofLabel = Ui.text(this, form, "이름·연락처는 가려지고, 인증 후 캡처는 삭제돼요.", 12, Ui.MUTED);

        new AlertDialog.Builder(this)
                .setTitle(company() + " 면접 후기")
                .setView(form)
                .setPositiveButton("올리기", (d, w) -> {
                    Models.ReviewRequest req = new Models.ReviewRequest();
                    req.userId = Api.userId(this);
                    req.role = role.getText().toString();
                    req.period = period.getText().toString();
                    req.stages = Arrays.asList(stages.getText().toString().split("\\s*,\\s*"));
                    for (String line : questions.getText().toString().split("\n")) {
                        if (!line.isBlank()) req.questions.add(line.trim());
                    }
                    req.mood = mood.getText().toString();
                    req.result = resultField.getText().toString();
                    req.detail = detail.getText().toString();
                    req.proofImageBase64 = proofBase64;
                    Api.call(this, Api.get().submitReview(company(), req), r -> {
                        Toast.makeText(this, "+" + r.earned + "P 받았어요 (보유 " + r.balance + "P)", Toast.LENGTH_LONG).show();
                        load();
                    });
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private EditText field(LinearLayout parent, String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        parent.addView(e);
        return e;
    }

    private void onProofPicked(Uri uri) {
        if (uri == null) return;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            // 대충 버전: 원본 그대로. 실서비스는 리사이즈 후 업로드
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            for (int n; (n = in.read(buf)) > 0; ) out.write(buf, 0, n);
            byte[] bytes = out.toByteArray();
            proofBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
            if (proofLabel != null) proofLabel.setText("캡처 첨부됨 · 검수 후 +100P");
        } catch (Exception e) {
            Toast.makeText(this, "이미지를 읽을 수 없어요", Toast.LENGTH_SHORT).show();
        }
    }
}
