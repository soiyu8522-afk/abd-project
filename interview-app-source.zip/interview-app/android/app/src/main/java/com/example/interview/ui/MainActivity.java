package com.example.interview.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.interview.net.Api;
import com.example.interview.net.Models;

/** 홈: 연속 연습 일수, 오늘의 퀘스트 요약, 각 기능 진입점 */
public class MainActivity extends AppCompatActivity {

    private TextView streakText;
    private TextView questSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);

        Ui.title(this, root, "오늘도 한 문항씩 단단하게");
        streakText = Ui.text(this, root, "", 14, Ui.ORANGE);

        Ui.button(this, root, "모의 면접 시작하기", Ui.BLUE,
                v -> startActivity(new Intent(this, InterviewerSelectActivity.class)));

        LinearLayout quest = Ui.card(this, root);
        Ui.heading(this, quest, "오늘의 퀘스트");
        questSummary = Ui.text(this, quest, "불러오는 중…", 14, Ui.MUTED);
        Ui.button(this, quest, "퀘스트 · 보스전", Ui.ORANGE, v -> startActivity(new Intent(this, QuestActivity.class)));

        LinearLayout prep = Ui.card(this, root);
        Ui.heading(this, prep, "면접 준비");
        Ui.button(this, prep, "자기소개서 피드백 · 예상 질문", Ui.INK,
                v -> startActivity(new Intent(this, CoverLetterActivity.class)));
        Ui.button(this, prep, "기업별 면접 정보 · 후기 공유", Ui.INK,
                v -> startActivity(new Intent(this, CompanyIntelActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        Api.call(this, Api.get().profile(Api.userId(this)), this::bind);
    }

    private void bind(Models.Profile p) {
        streakText.setText(p.streak + "일 연속 연습 중 · Lv." + p.level + " · " + p.points + "P");
        long done = p.quests.stream().filter(q -> q.done >= q.goal).count();
        StringBuilder sb = new StringBuilder(done + " / " + p.quests.size() + " 완료\n");
        for (Models.QuestView q : p.quests) {
            sb.append(q.done >= q.goal ? "✓ " : "○ ").append(q.title).append("  +").append(q.xp).append(" XP\n");
        }
        questSummary.setText(sb.toString().trim());
    }
}
