package com.example.interview.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.interview.net.Api;
import com.example.interview.net.Models;
import com.google.gson.Gson;

/** 면접 리포트: 녹화 영상 다시 보기, 태도 점수, 문항별 피드백, 면접관 속마음 리플레이 */
public class ReportActivity extends AppCompatActivity {

    public static final String EXTRA_REQUEST = "reportRequest";
    public static final String EXTRA_VIDEO = "videoUri";

    private VideoView video;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);
        Ui.title(this, root, "면접 리포트");
        TextView status = Ui.text(this, root, "AI가 답변과 태도를 분석하고 있어요…", 14, Ui.MUTED);

        String uri = getIntent().getStringExtra(EXTRA_VIDEO);
        if (uri != null) {
            video = new VideoView(this);
            video.setVideoURI(Uri.parse(uri));
            video.setMediaController(new MediaController(this));
            root.addView(video, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 220)));
        }

        Models.ReportRequest req = new Gson().fromJson(getIntent().getStringExtra(EXTRA_REQUEST), Models.ReportRequest.class);
        Api.call(this, Api.get().report(req), r -> {
            status.setText("종합 " + r.overall + " / 100");
            bind(root, req, r);
            Api.call(this, Api.get().event(Api.userId(this), new Models.Event("GAZE_SCORE", req.persona, r.scores.gaze)), p -> {});
        });
    }

    private void bind(LinearLayout root, Models.ReportRequest req, Models.Report r) {
        LinearLayout scores = Ui.card(this, root);
        Ui.heading(this, scores, "태도 분석");
        Ui.text(this, scores, "시선 처리 " + r.scores.gaze + "  ·  자세 " + r.scores.posture
                + "  ·  말 속도 " + r.scores.pace + "\n답변 구조 " + r.scores.structure + "  ·  습관어 " + r.scores.filler, 14, Ui.INK);

        LinearLayout perQ = Ui.card(this, root);
        Ui.heading(this, perQ, "문항별 피드백");
        for (Models.QuestionFeedback f : r.perQuestion) {
            Models.Turn t = f.index < req.turns.size() ? req.turns.get(f.index) : null;
            TextView q = Ui.text(this, perQ, "Q" + (f.index + 1) + ". " + (t == null ? "" : t.question), 14, Ui.INK);
            q.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            if (t != null && video != null) {
                // 문항을 누르면 그 답변 시점으로 영상 이동
                q.setOnClickListener(v -> { video.seekTo(t.startSec * 1000); video.start(); });
            }
            Ui.text(this, perQ, "잘한 점: " + f.good, 13, Ui.BLUE);
            Ui.text(this, perQ, "개선점: " + f.fix, 13, Ui.ORANGE);
        }

        LinearLayout inner = Ui.card(this, root);
        Ui.heading(this, inner, "면접관 속마음 보기");
        for (Models.InnerVoice v : r.innerVoice) {
            TextView row = Ui.text(this, inner, v.time + "  “" + v.thought + "”\n" + v.mood + " · " + v.cause, 13, Ui.INK);
            if (video != null) row.setOnClickListener(x -> { video.seekTo(toMs(v.time)); video.start(); });
        }

        Ui.button(this, root, "퀘스트 보상 받으러 가기", Ui.ORANGE, v -> startActivity(new Intent(this, QuestActivity.class)));
    }

    private static int toMs(String mmss) {
        try {
            String[] p = mmss.split(":");
            return (Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1])) * 1000;
        } catch (Exception e) {
            return 0;
        }
    }
}
