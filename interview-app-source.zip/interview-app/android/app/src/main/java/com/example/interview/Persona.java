package com.example.interview;

/** 서버의 Persona enum 과 이름을 맞춘다. */
public enum Persona {
    MENTOR("따뜻한 멘토형", "편안하게 경험을 끌어내고 격려해 줘요", 0.95f, 1.05f),
    PRESSURE("냉철한 압박형", "답변의 허점을 짧고 날카롭게 파고들어요", 1.15f, 0.9f),
    LOGIC("논리 분석형", "근거와 수치, 답변 구조를 꼼꼼히 봐요", 1.0f, 1.0f),
    CASUAL("유쾌한 대화형", "대화하듯 가볍게 가치관과 컬처핏을 봐요", 1.05f, 1.1f),
    EXECUTIVE("깐깐한 임원형", "보스전 클리어 시 해금", 0.95f, 0.85f);

    public final String label;
    public final String tagline;
    /** TextToSpeech 말 속도/톤 (성향마다 다르게) */
    public final float speechRate;
    public final float pitch;

    Persona(String label, String tagline, float speechRate, float pitch) {
        this.label = label;
        this.tagline = tagline;
        this.speechRate = speechRate;
        this.pitch = pitch;
    }
}
