package com.example.interview.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.interview.Persona;
import com.example.interview.interview.InterviewActivity;

import java.util.ArrayList;

/**
 * 1단계: 면접관 성향 / 직무 / 질문 수 선택
 * 2단계: 피드백 방식(실시간 / 녹화 후) 선택 → 면접 시작
 * 다른 화면(자소서 예상 질문, 기업 정보)에서 넘어오면 seedQuestions / company 를 그대로 넘긴다.
 */
public class InterviewerSelectActivity extends AppCompatActivity {

    private static final String[] JOBS = {"개발", "디자인", "마케팅", "영업", "공기업"};
    private static final int[] COUNTS = {3, 5, 10};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);
        Ui.title(this, root, "어떤 면접관과 연습할까요?");
        Ui.text(this, root, "성향에 따라 질문 방식과 반응이 달라져요", 14, Ui.MUTED);

        RadioGroup personas = new RadioGroup(this);
        for (Persona p : Persona.values()) {
            // TODO: 보스전 클리어 여부를 프로필에서 받아 EXECUTIVE 잠금 처리
            RadioButton rb = new RadioButton(this);
            rb.setText(p.label + "\n" + p.tagline);
            rb.setTag(p);
            rb.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            personas.addView(rb);
            if (p == Persona.PRESSURE) rb.setChecked(true);
        }
        Ui.card(this, root).addView(personas);

        LinearLayout opts = Ui.card(this, root);
        Ui.heading(this, opts, "지원 직무");
        Spinner job = new Spinner(this);
        job.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, JOBS));
        opts.addView(job);
        Ui.heading(this, opts, "질문 개수");
        RadioGroup count = new RadioGroup(this);
        count.setOrientation(RadioGroup.HORIZONTAL);
        for (int c : COUNTS) {
            RadioButton rb = new RadioButton(this);
            rb.setText(c + "문항");
            rb.setTag(c);
            count.addView(rb);
            if (c == 5) rb.setChecked(true);
        }
        opts.addView(count);

        Ui.button(this, root, "다음: 피드백 방식 고르기", Ui.BLUE, v -> {
            Persona p = (Persona) findViewById(personas.getCheckedRadioButtonId()).getTag();
            int n = (int) findViewById(count.getCheckedRadioButtonId()).getTag();
            chooseMode(p, (String) job.getSelectedItem(), n);
        });
    }

    private void chooseMode(Persona persona, String job, int count) {
        String[] labels = {
                "실시간 피드백 — 면접 중 시선·말 속도·습관어를 바로 알려줘요",
                "녹화 후 피드백 — 면접에만 집중하고, 끝나면 영상과 상세 리포트"};
        new AlertDialog.Builder(this)
                .setTitle("피드백은 언제 받을까요?")
                .setItems(labels, (d, which) -> {
                    Intent i = new Intent(this, InterviewActivity.class);
                    i.putExtra(InterviewActivity.EXTRA_PERSONA, persona.name());
                    i.putExtra(InterviewActivity.EXTRA_JOB, job);
                    i.putExtra(InterviewActivity.EXTRA_COUNT, count);
                    i.putExtra(InterviewActivity.EXTRA_MODE, which == 0 ? "LIVE" : "AFTER");
                    ArrayList<String> seeds = getIntent().getStringArrayListExtra(InterviewActivity.EXTRA_SEEDS);
                    if (seeds != null) i.putStringArrayListExtra(InterviewActivity.EXTRA_SEEDS, seeds);
                    i.putExtra(InterviewActivity.EXTRA_COMPANY, getIntent().getStringExtra(InterviewActivity.EXTRA_COMPANY));
                    startActivity(i);
                })
                .show();
    }
}
