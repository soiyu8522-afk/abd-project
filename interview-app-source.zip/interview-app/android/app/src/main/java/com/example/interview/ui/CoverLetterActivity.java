package com.example.interview.ui;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.interview.interview.InterviewActivity;
import com.example.interview.net.Api;
import com.example.interview.net.Models;

import java.util.ArrayList;

/** 자기소개서 피드백(문장 하이라이트) + 자소서 기반 예상 질문 */
public class CoverLetterActivity extends AppCompatActivity {

    private EditText questionInput, textInput, jobPostInput;
    private LinearLayout result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);
        Ui.title(this, root, "자기소개서 피드백");

        questionInput = input(root, "자소서 문항 (예: 지원 동기와 입사 후 포부)", 1);
        textInput = input(root, "자소서 내용을 붙여넣어 주세요", 8);
        jobPostInput = input(root, "지원 공고 (선택)", 3);

        Ui.button(this, root, "문장별 피드백 받기", Ui.BLUE, v -> requestFeedback());
        Ui.button(this, root, "이 자소서로 예상 질문 뽑기", Ui.INK, v -> requestQuestions());

        result = Ui.column(this);
        root.addView(result);
    }

    private EditText input(LinearLayout parent, String hint, int lines) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setMinLines(lines);
        e.setBackgroundColor(Color.WHITE);
        int p = Ui.dp(this, 12);
        e.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 12);
        parent.addView(e, lp);
        return e;
    }

    private String jobPost() {
        String s = jobPostInput.getText().toString().trim();
        return s.isEmpty() ? null : s;
    }

    // ---------- 문장 피드백 ----------

    private void requestFeedback() {
        String text = textInput.getText().toString();
        loading();
        Api.call(this, Api.get().coverLetterFeedback(
                new Models.CoverLetterRequest(questionInput.getText().toString(), text, jobPost())), f -> showFeedback(text, f));
    }

    private void showFeedback(String original, Models.CoverLetterFeedback f) {
        result.removeAllViews();
        LinearLayout scores = Ui.card(this, result);
        Ui.heading(this, scores, "점수");
        Ui.text(this, scores, "구체성 " + f.scores.specificity + " · 직무 연관 " + f.scores.jobFit
                + " · 가독성 " + f.scores.readability + " · 차별성 " + f.scores.uniqueness, 14, Ui.INK);

        LinearLayout body = Ui.card(this, result);
        Ui.heading(this, body, "본문 (주황: 고칠 문장, 파랑: 살릴 문장 — 눌러 보세요)");
        TextView textView = Ui.text(this, body, "", 15, Ui.INK);
        LinearLayout note = Ui.card(this, result);
        TextView noteText = Ui.text(this, note, "표시된 문장을 누르면 이유와 고친 문장이 나와요.", 14, Ui.MUTED);

        SpannableString span = new SpannableString(original);
        for (Models.SentenceFeedback s : f.sentences) {
            int start = original.indexOf(s.text);
            if (start < 0) continue; // AI가 문장을 살짝 바꿔 돌려준 경우는 건너뜀
            int end = start + s.text.length();
            boolean fix = "FIX".equals(s.kind);
            span.setSpan(new BackgroundColorSpan(Color.parseColor(fix ? "#FED7AA" : "#C7D2FE")), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            span.setSpan(new ClickableSpan() {
                @Override public void onClick(@NonNull View widget) {
                    String msg = (fix ? "고칠 점 · " : "잘한 점 · ") + s.title + "\n" + s.why;
                    if (fix && s.rewrite != null && !s.rewrite.isEmpty()) msg += "\n\n이렇게 바꿔 보세요:\n" + s.rewrite;
                    noteText.setText(msg);
                    noteText.setTextColor(fix ? Ui.ORANGE : Ui.BLUE);
                }
                @Override public void updateDrawState(@NonNull TextPaint ds) {
                    ds.setColor(Ui.INK); // 링크 파란 밑줄 대신 하이라이트만
                }
            }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        textView.setText(span);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    // ---------- 예상 질문 ----------

    private void requestQuestions() {
        loading();
        Api.call(this, Api.get().coverLetterQuestions(
                new Models.CoverQuestionsRequest(textInput.getText().toString(), jobPost())), this::showQuestions);
    }

    private void showQuestions(Models.PredictedQuestions qs) {
        result.removeAllViews();
        Ui.heading(this, result, "면접관은 자소서의 이 문장들을 파고들 거예요");
        ArrayList<String> all = new ArrayList<>();
        for (Models.PredictedQuestion q : qs.questions) {
            all.add(q.question);
            LinearLayout c = Ui.card(this, result);
            Ui.text(this, c, (q.priority ? "[우선 연습] " : "") + q.type, 12, Ui.ORANGE);
            Ui.text(this, c, "“" + q.quote + "”", 13, Ui.MUTED);
            Ui.heading(this, c, q.question);
            TextView guide = Ui.text(this, c, "답변 가이드: " + q.guide, 13, Ui.BLUE);
            guide.setVisibility(View.GONE);
            Ui.button(this, c, "답변 가이드 보기", Ui.MUTED, v -> guide.setVisibility(View.VISIBLE));
            Ui.button(this, c, "이 질문 연습하기", Ui.BLUE, v -> practice(single(q.question)));
        }
        Ui.button(this, result, "전체 질문으로 모의 면접 보기", Ui.BLUE, v -> practice(all));
    }

    private static ArrayList<String> single(String q) {
        ArrayList<String> l = new ArrayList<>();
        l.add(q);
        return l;
    }

    private void practice(ArrayList<String> seeds) {
        Intent i = new Intent(this, InterviewerSelectActivity.class);
        i.putStringArrayListExtra(InterviewActivity.EXTRA_SEEDS, seeds);
        startActivity(i);
    }

    private void loading() {
        result.removeAllViews();
        Ui.text(this, result, "AI가 읽고 있어요…", 14, Ui.MUTED);
    }
}
