package com.example.interview.net;

import com.example.interview.net.Models.*;

import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {

    @POST("api/interview/next-question")
    Call<NextQuestion> nextQuestion(@Body NextQuestionRequest req);

    @POST("api/interview/report")
    Call<Report> report(@Body ReportRequest req);

    @POST("api/interview/live-tip")
    Call<LiveTip> liveTip(@Body LiveSignal s);

    @GET("api/interview/curveball")
    Call<Curveball> curveball();

    @POST("api/cover-letter/feedback")
    Call<CoverLetterFeedback> coverLetterFeedback(@Body CoverLetterRequest req);

    @POST("api/cover-letter/questions")
    Call<PredictedQuestions> coverLetterQuestions(@Body CoverQuestionsRequest req);

    @GET("api/users/{userId}/profile")
    Call<Profile> profile(@Path("userId") String userId);

    @POST("api/users/{userId}/events")
    Call<Profile> event(@Path("userId") String userId, @Body Event e);

    @POST("api/users/{userId}/quests/{questId}/claim")
    Call<Profile> claim(@Path("userId") String userId, @Path("questId") String questId);

    @GET("api/companies/{company}")
    Call<CompanySummary> company(@Path("company") String company, @Query("userId") String userId);

    @GET("api/companies/{company}/context")
    Call<CompanyContext> companyContext(@Path("company") String company);

    @POST("api/companies/{company}/reviews")
    Call<PointResult> submitReview(@Path("company") String company, @Body ReviewRequest req);

    @POST("api/companies/{company}/reviews/{reviewId}/unlock")
    Call<PointResult> unlock(@Path("company") String company, @Path("reviewId") String reviewId,
                             @Query("userId") String userId);
}
