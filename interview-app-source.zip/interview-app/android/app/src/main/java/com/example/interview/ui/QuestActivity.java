package com.example.interview.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.interview.net.Api;
import com.example.interview.net.Models;

/** 데일리 퀘스트 + 주말 보스전 진입 */
public class QuestActivity extends AppCompatActivity {

    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = Ui.screen(this);
        Api.call(this, Api.get().profile(Api.userId(this)), this::bind);
    }

    private void bind(Models.Profile p) {
        root.removeAllViews();
        Ui.title(this, root, "데일리 퀘스트");
        Ui.text(this, root, p.streak + "일 연속 (최고 " + p.bestStreak + "일) · Lv." + p.level
                + " · 다음 레벨까지 " + (p.xp % 500) + " / 500 XP", 14, Ui.ORANGE);

        for (Models.QuestView q : p.quests) {
            LinearLayout c = Ui.card(this, root);
            Ui.heading(this, c, q.title);
            Ui.text(this, c, q.done + " / " + q.goal + " · +" + q.xp + " XP", 13, Ui.MUTED);
            if (q.done >= q.goal && !q.claimed) {
                Ui.button(this, c, "+" + q.xp + " XP 받기", Ui.ORANGE,
                        v -> Api.call(this, Api.get().claim(Api.userId(this), q.id), this::bind));
            } else if (q.claimed) {
                Button b = Ui.button(this, c, "받음", Ui.MUTED, v -> {});
                b.setEnabled(false);
            }
        }

        LinearLayout boss = Ui.card(this, root);
        Ui.heading(this, boss, "주말 보스전 · 깐깐한 임원 3인 패널");
        Ui.text(this, boss, "10문항 최종 면접, 설득 게이지 80% 이상이면 클리어. 주 3회 도전.\n"
                + "보상: 배지, 새 면접관 ‘깐깐한 임원형’, +500 XP", 13, Ui.MUTED);
        // TODO: 보스전 전용 세션(EXECUTIVE 패널 + 돌발 카드 2장 고정) → 리포트 overall 을 /boss 로 보내기
    }
}
