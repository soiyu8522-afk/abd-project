package com.example.interview.ui;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 화면을 빨리 만들기 위한 아주 작은 코드 레이아웃 헬퍼.
 * (면접 화면만 XML, 나머지는 이걸로 대충 그림. 다듬을 때 XML/Compose 로 옮기면 됨)
 */
public final class Ui {
    private Ui() {}

    public static final int BLUE = Color.parseColor("#2448D8");
    public static final int ORANGE = Color.parseColor("#C2410C");
    public static final int INK = Color.parseColor("#111827");
    public static final int MUTED = Color.parseColor("#4B5563");

    /** 스크롤되는 세로 화면을 만들고 그 안의 컨테이너를 돌려준다 */
    public static LinearLayout screen(Activity a) {
        ScrollView scroll = new ScrollView(a);
        scroll.setBackgroundColor(Color.parseColor("#F3F4F6"));
        LinearLayout col = column(a);
        int p = dp(a, 20);
        col.setPadding(p, dp(a, 32), p, p);
        scroll.addView(col);
        a.setContentView(scroll);
        return col;
    }

    public static LinearLayout column(Activity a) {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout card(Activity a, ViewGroup parent) {
        LinearLayout c = column(a);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(a, 16));
        c.setBackground(bg);
        int p = dp(a, 16);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(a, 12);
        parent.addView(c, lp);
        return c;
    }

    public static TextView title(Activity a, ViewGroup parent, String text) {
        TextView t = text(a, parent, text, 24, INK);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView heading(Activity a, ViewGroup parent, String text) {
        TextView t = text(a, parent, text, 16, INK);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView text(Activity a, ViewGroup parent, String text, int sp, int color) {
        TextView t = new TextView(a);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.3f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(a, 4);
        parent.addView(t, lp);
        return t;
    }

    public static Button button(Activity a, ViewGroup parent, String label, int color, View.OnClickListener onClick) {
        Button b = new Button(a);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        b.setOnClickListener(onClick);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 54));
        lp.topMargin = dp(a, 12);
        parent.addView(b, lp);
        return b;
    }

    public static int dp(Activity a, int v) {
        return Math.round(v * a.getResources().getDisplayMetrics().density);
    }
}
