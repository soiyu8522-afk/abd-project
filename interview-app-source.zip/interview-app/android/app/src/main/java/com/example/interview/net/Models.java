package com.example.interview.net;

import java.util.ArrayList;
import java.util.List;

/** 서버 Dtos 와 같은 모양의 Gson 모델 (대충 public 필드) */
public final class Models {
    private Models() {}

    public static class Turn {
        public String question;
        public String answer;
        public int startSec;
        public int endSec;

        public Turn(String question, String answer, int startSec, int endSec) {
            this.question = question;
            this.answer = answer;
            this.startSec = startSec;
            this.endSec = endSec;
        }
    }

    public static class NextQuestionRequest {
        public String persona;
        public String job;
        public int questionCount;
        public List<Turn> history = new ArrayList<>();
        public List<String> seedQuestions = new ArrayList<>();
        public String companyContext;
    }

    public static class NextQuestion {
        public String question;
        public boolean followUp;
        public boolean done;
    }

    public static class AttitudeMetrics {
        public double gazeAwayRatio;
        public int fillerCount;
        public double wordsPerMinute;
        public double postureScore;
        public List<Integer> gazeAwaySeconds = new ArrayList<>();
    }

    public static class ReportRequest {
        public String persona;
        public String mode; // LIVE / AFTER
        public List<Turn> turns;
        public AttitudeMetrics metrics;
    }

    public static class Scores { public int gaze, posture, pace, structure, filler; }

    public static class QuestionFeedback { public int index; public String good; public String fix; }

    public static class InnerVoice { public String time, thought, mood, cause; }

    public static class Report {
        public int overall;
        public Scores scores;
        public List<QuestionFeedback> perQuestion;
        public List<InnerVoice> innerVoice;
    }

    public static class LiveSignal {
        public double gazeAwayRatio;
        public int fillerCount;
        public double wordsPerMinute;
    }

    public static class LiveTip { public String gaze, pace, filler; }

    public static class Curveball { public String title, description, tip; public int seconds, panelSize; }

    public static class CoverLetterRequest {
        public String question, text, jobPost;

        public CoverLetterRequest(String question, String text, String jobPost) {
            this.question = question;
            this.text = text;
            this.jobPost = jobPost;
        }
    }

    public static class SentenceFeedback { public String text, kind, title, why, rewrite; }

    public static class CoverLetterScores { public int specificity, jobFit, readability, uniqueness; }

    public static class CoverLetterFeedback {
        public CoverLetterScores scores;
        public List<SentenceFeedback> sentences;
    }

    public static class CoverQuestionsRequest {
        public String coverLetter, jobPost;

        public CoverQuestionsRequest(String coverLetter, String jobPost) {
            this.coverLetter = coverLetter;
            this.jobPost = jobPost;
        }
    }

    public static class PredictedQuestion { public String type, quote, question, guide; public boolean priority; }

    public static class PredictedQuestions { public List<PredictedQuestion> questions; }

    public static class QuestView { public String id, title; public int done, goal, xp; public boolean claimed; }

    public static class Profile {
        public int level, xp, points, streak, bestStreak;
        public List<QuestView> quests;
    }

    public static class Event {
        public String type;     // INTRO_RECORDED / INTERVIEW_DONE / ANSWERED / GAZE_SCORE
        public String persona;
        public Integer value;

        public Event(String type, String persona, Integer value) {
            this.type = type;
            this.persona = persona;
            this.value = value;
        }
    }

    public static class ReviewRequest {
        public String userId, role, period, mood, result, detail, proofImageBase64;
        public List<String> stages = new ArrayList<>();
        public List<String> questions = new ArrayList<>();
    }

    public static class PointResult { public int earned, balance; }

    public static class QuestionStat { public String question; public long count; }

    public static class ReviewPreview { public String id, role, period, result, detail; public boolean verified, locked; }

    public static class CompanySummary {
        public String company;
        public int reviewCount;
        public List<String> stages, moods;
        public List<QuestionStat> questions;
        public List<ReviewPreview> reviews;
    }

    public static class CompanyContext { public String context; }
}
