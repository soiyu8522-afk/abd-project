package com.example.interview.interview;

import androidx.annotation.OptIn;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageProxy;

import com.example.interview.net.Models;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * 카메라 프레임과 음성 인식 결과로 태도 지표를 계산한다. 전부 기기 안에서 처리.
 * - 시선: 얼굴이 안 보이거나 고개가 많이 돌아가면 '이탈'
 * - 자세: 고개 기울기(roll)가 작을수록 높은 점수
 * - 습관어/말 속도: 인식된 답변 텍스트로 계산
 */
public class MetricsTracker {

    private static final float GAZE_YAW_LIMIT = 20f;
    private static final float GAZE_PITCH_LIMIT = 15f;
    private static final Set<String> FILLERS = Set.of("음", "어", "그", "저", "그러니까", "약간", "뭐랄까", "이제");

    private final FaceDetector detector = FaceDetection.getClient(
            new FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .build());

    private final long startMs = System.currentTimeMillis();
    private long frames;
    private long awayFrames;
    private double postureSum;
    private int lastAwaySecond = -1;
    private final List<Integer> awaySeconds = new ArrayList<>();

    // 최근 5초 실시간 피드백용
    private long recentFrames;
    private long recentAway;

    private final StringBuilder answers = new StringBuilder();
    private long speakingMs;

    @OptIn(markerClass = ExperimentalGetImage.class)
    public void analyze(ImageProxy proxy) {
        if (proxy.getImage() == null) {
            proxy.close();
            return;
        }
        InputImage image = InputImage.fromMediaImage(proxy.getImage(), proxy.getImageInfo().getRotationDegrees());
        detector.process(image)
                .addOnSuccessListener(this::onFaces)
                .addOnCompleteListener(t -> proxy.close());
    }

    private synchronized void onFaces(List<Face> faces) {
        frames++;
        recentFrames++;
        boolean away = faces.isEmpty();
        if (!away) {
            Face f = faces.get(0);
            away = Math.abs(f.getHeadEulerAngleY()) > GAZE_YAW_LIMIT || Math.abs(f.getHeadEulerAngleX()) > GAZE_PITCH_LIMIT;
            postureSum += Math.max(0, 100 - Math.abs(f.getHeadEulerAngleZ()) * 4);
        }
        if (away) {
            awayFrames++;
            recentAway++;
            int sec = elapsedSec();
            if (sec != lastAwaySecond) {
                awaySeconds.add(sec);
                lastAwaySecond = sec;
            }
        }
    }

    public synchronized void addAnswer(String text, long durationMs) {
        answers.append(text).append(' ');
        speakingMs += durationMs;
    }

    public int elapsedSec() {
        return (int) ((System.currentTimeMillis() - startMs) / 1000);
    }

    public synchronized int fillerCount() {
        int n = 0;
        for (String w : answers.toString().split("\\s+")) {
            if (FILLERS.contains(w.replaceAll("[.,…~!?]", ""))) n++;
        }
        return n;
    }

    public synchronized double wordsPerMinute() {
        if (speakingMs < 1000) return 0;
        int words = answers.toString().trim().isEmpty() ? 0 : answers.toString().trim().split("\\s+").length;
        return words / (speakingMs / 60000.0);
    }

    /** 실시간 모드에서 5초마다 호출 */
    public synchronized Models.LiveSignal liveSignal() {
        Models.LiveSignal s = new Models.LiveSignal();
        s.gazeAwayRatio = recentFrames == 0 ? 0 : (double) recentAway / recentFrames;
        s.fillerCount = fillerCount();
        s.wordsPerMinute = wordsPerMinute();
        recentFrames = 0;
        recentAway = 0;
        return s;
    }

    public synchronized Models.AttitudeMetrics build() {
        Models.AttitudeMetrics m = new Models.AttitudeMetrics();
        m.gazeAwayRatio = frames == 0 ? 0 : (double) awayFrames / frames;
        m.fillerCount = fillerCount();
        m.wordsPerMinute = wordsPerMinute();
        long faceFrames = frames - awayFrames;
        m.postureScore = faceFrames <= 0 ? 0 : postureSum / Math.max(1, frames);
        m.gazeAwaySeconds = compress(awaySeconds);
        return m;
    }

    public void close() {
        detector.close();
    }

    /** 연속된 초는 시작 초만 남겨서 서버로 보내는 양을 줄인다 */
    private static List<Integer> compress(List<Integer> secs) {
        List<Integer> out = new ArrayList<>();
        int prev = -10;
        for (int s : secs) {
            if (s - prev > 1) out.add(s);
            prev = s;
        }
        return out;
    }
}
