package com.example.interview.interview;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.example.interview.Persona;
import com.example.interview.R;
import com.example.interview.net.Api;
import com.example.interview.net.Models;
import com.example.interview.ui.ReportActivity;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 면접 진행 화면.
 * 1) 서버에서 다음 질문을 받아 TextToSpeech 로 면접관이 직접 말한다
 * 2) 전면 카메라로 녹화하면서 ML Kit 로 시선/자세를 측정한다
 * 3) SpeechRecognizer 로 답변을 받아 적는다
 * 4) LIVE 모드면 5초마다 실시간 팁을 띄운다
 */
public class InterviewActivity extends AppCompatActivity {

    public static final String EXTRA_PERSONA = "persona";
    public static final String EXTRA_JOB = "job";
    public static final String EXTRA_COUNT = "count";
    public static final String EXTRA_MODE = "mode";             // LIVE / AFTER
    public static final String EXTRA_SEEDS = "seedQuestions";   // 자소서/공고에서 고른 질문
    public static final String EXTRA_COMPANY = "company";       // 기업 후기 기반 면접

    /** 돌발 상황 카드가 나올 확률 (설정: 없음 0 / 가끔 0.2 / 자주 0.4) */
    private static final double CURVEBALL_CHANCE = 0.2;

    /**
     * 녹화 영상에 소리까지 넣으면 많은 기기에서 SpeechRecognizer 와 마이크가 충돌한다.
     * 대충 버전은 영상은 무음으로 찍고 음성은 받아쓰기에 쓴다.
     */
    private static final boolean RECORD_AUDIO_IN_VIDEO = false;

    private Persona persona;
    private String mode;
    private final Models.NextQuestionRequest req = new Models.NextQuestionRequest();
    private final ArrayList<Models.Turn> turns = new ArrayList<>();

    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private MetricsTracker metrics;
    private VideoCapture<Recorder> videoCapture;
    private Recording recording;
    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private String currentQuestion;
    private final StringBuilder currentAnswer = new StringBuilder();
    private int answerStartSec;
    private long answerStartMs;
    private boolean listening;
    private boolean ending;

    private TextView questionText, speakState, recText, progressText, gazeTip, paceTip, fillerTip;
    private Button nextBtn;
    private View curveCard;

    private final ActivityResultLauncher<String[]> permissions =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), granted -> {
                if (Boolean.TRUE.equals(granted.get(Manifest.permission.CAMERA))
                        && Boolean.TRUE.equals(granted.get(Manifest.permission.RECORD_AUDIO))) {
                    start();
                } else {
                    questionText.setText("카메라와 마이크 권한이 있어야 면접을 녹화할 수 있어요.");
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interview);

        persona = Persona.valueOf(getIntent().getStringExtra(EXTRA_PERSONA));
        mode = getIntent().getStringExtra(EXTRA_MODE);
        req.persona = persona.name();
        req.job = getIntent().getStringExtra(EXTRA_JOB);
        req.questionCount = getIntent().getIntExtra(EXTRA_COUNT, 5);
        ArrayList<String> seeds = getIntent().getStringArrayListExtra(EXTRA_SEEDS);
        if (seeds != null) req.seedQuestions = seeds;

        questionText = findViewById(R.id.questionText);
        speakState = findViewById(R.id.speakState);
        recText = findViewById(R.id.recText);
        progressText = findViewById(R.id.progressText);
        gazeTip = findViewById(R.id.gazeTip);
        paceTip = findViewById(R.id.paceTip);
        fillerTip = findViewById(R.id.fillerTip);
        nextBtn = findViewById(R.id.nextBtn);
        curveCard = findViewById(R.id.curveCard);

        ((TextView) findViewById(R.id.personaText)).setText(persona.label);
        setInterviewerImage();
        boolean live = "LIVE".equals(mode);
        findViewById(R.id.liveRow).setVisibility(live ? View.VISIBLE : View.GONE);
        findViewById(R.id.afterNote).setVisibility(live ? View.GONE : View.VISIBLE);

        findViewById(R.id.replayBtn).setOnClickListener(v -> speak(currentQuestion));
        nextBtn.setOnClickListener(v -> finishAnswer());
        findViewById(R.id.endBtn).setOnClickListener(v -> endInterview());
        findViewById(R.id.curveOk).setOnClickListener(v -> {
            curveCard.setVisibility(View.GONE);
            startListening();
        });

        permissions.launch(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO});
    }

    private void start() {
        metrics = new MetricsTracker();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.KOREAN);
                tts.setSpeechRate(persona.speechRate);
                tts.setPitch(persona.pitch);
            }
        });
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { ui.post(() -> speakState.setText("면접관이 질문하는 중…")); }
            @Override public void onDone(String id) { ui.post(() -> startListening()); }
            @Override public void onError(String id) { ui.post(() -> startListening()); }
        });
        setupRecognizer();
        startCamera();
        startTimers();

        String company = getIntent().getStringExtra(EXTRA_COMPANY);
        if (company != null) {
            Api.call(this, Api.get().companyContext(company), c -> {
                req.companyContext = c.context;
                askNext();
            });
        } else {
            askNext();
        }
    }

    // ---------- 카메라 / 녹화 ----------

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(((PreviewView) findViewById(R.id.previewView)).getSurfaceProvider());

                Recorder recorder = new Recorder.Builder()
                        .setQualitySelector(QualitySelector.from(Quality.HD))
                        .build();
                videoCapture = VideoCapture.withOutput(recorder);

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analysis.setAnalyzer(analysisExecutor, metrics::analyze);

                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, videoCapture, analysis);
                startRecording();
            } catch (Exception e) {
                questionText.setText("카메라를 열 수 없어요: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @SuppressLint("MissingPermission") // 위에서 권한을 받은 뒤에만 호출됨
    private void startRecording() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "interview_" + System.currentTimeMillis());
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        MediaStoreOutputOptions options = new MediaStoreOutputOptions.Builder(
                getContentResolver(), MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                .setContentValues(values)
                .build();

        PendingRecording pending = videoCapture.getOutput().prepareRecording(this, options);
        if (RECORD_AUDIO_IN_VIDEO) pending = pending.withAudioEnabled();
        recording = pending.start(ContextCompat.getMainExecutor(this), event -> {
            if (event instanceof VideoRecordEvent.Finalize) {
                Uri uri = ((VideoRecordEvent.Finalize) event).getOutputResults().getOutputUri();
                openReport(uri);
            }
        });
    }

    // ---------- 질문 / 음성 ----------

    private void askNext() {
        nextBtn.setEnabled(false);
        req.history = turns;
        Api.call(this, Api.get().nextQuestion(req), q -> {
            if (q.done) {
                endInterview();
                return;
            }
            long mainAnswered = turns.size();
            progressText.setText("질문 " + Math.min(mainAnswered + 1, req.questionCount) + " / " + req.questionCount);

            // 돌발 상황 카드: 꼬리질문이 아닐 때 가끔 끼어든다
            if (!q.followUp && !turns.isEmpty() && random.nextDouble() < CURVEBALL_CHANCE) {
                showCurveball();
            } else {
                showQuestion(q.question);
            }
        });
    }

    private void showQuestion(String question) {
        currentQuestion = question;
        questionText.setText(question);
        speak(question);
    }

    private void showCurveball() {
        Api.call(this, Api.get().curveball(), c -> {
            currentQuestion = c.title;
            ((TextView) findViewById(R.id.curveTitle)).setText(c.title);
            ((TextView) findViewById(R.id.curveDesc)).setText(c.description);
            ((TextView) findViewById(R.id.curveTip)).setText("대응 팁: " + c.tip);
            questionText.setText(c.title);
            curveCard.setVisibility(View.VISIBLE);
            tts.speak(c.title, TextToSpeech.QUEUE_FLUSH, null, null); // 카드에서 버튼을 눌러야 답변 시작
        });
    }

    private void speak(String text) {
        if (text == null || tts == null) return;
        stopListening();
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "q");
    }

    private void setupRecognizer() {
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onResults(Bundle results) {
                ArrayList<String> texts = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (texts != null && !texts.isEmpty()) currentAnswer.append(texts.get(0)).append(' ');
                // 말을 잠깐 멈추면 인식이 끝나므로, 답변 중이면 다시 듣기 시작
                if (listening) listenOnce();
            }
            @Override public void onError(int error) { if (listening) ui.postDelayed(() -> listenOnce(), 300); }
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void startListening() {
        if (curveCard.getVisibility() == View.VISIBLE) return;
        currentAnswer.setLength(0);
        answerStartSec = metrics.elapsedSec();
        answerStartMs = System.currentTimeMillis();
        listening = true;
        speakState.setText("답변을 시작하세요");
        nextBtn.setEnabled(true);
        listenOnce();
    }

    private void listenOnce() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizer.startListening(intent);
    }

    private void stopListening() {
        listening = false;
        if (recognizer != null) recognizer.stopListening();
    }

    private void finishAnswer() {
        stopListening();
        // stopListening 직후 마지막 결과가 들어올 시간을 조금 준다
        ui.postDelayed(() -> {
            String answer = currentAnswer.toString().trim();
            metrics.addAnswer(answer, System.currentTimeMillis() - answerStartMs);
            turns.add(new Models.Turn(currentQuestion, answer, answerStartSec, metrics.elapsedSec()));
            Api.call(this, Api.get().event(Api.userId(this), new Models.Event("ANSWERED", persona.name(), null)), p -> {});
            askNext();
        }, 600);
    }

    // ---------- 타이머 / 실시간 피드백 ----------

    private void startTimers() {
        ui.post(new Runnable() {
            @Override public void run() {
                int s = metrics.elapsedSec();
                recText.setText(String.format(Locale.US, "● REC %02d:%02d", s / 60, s % 60));
                ui.postDelayed(this, 1000);
            }
        });
        if ("LIVE".equals(mode)) {
            ui.postDelayed(new Runnable() {
                @Override public void run() {
                    Api.call(InterviewActivity.this, Api.get().liveTip(metrics.liveSignal()), tip -> {
                        gazeTip.setText("시선\n" + tip.gaze);
                        paceTip.setText("말 속도\n" + tip.pace);
                        fillerTip.setText("습관어\n" + tip.filler);
                    });
                    ui.postDelayed(this, 5000);
                }
            }, 5000);
        }
    }

    // ---------- 종료 ----------

    private void endInterview() {
        if (ending) return;
        ending = true;
        stopListening();
        if (tts != null) tts.stop();
        ui.removeCallbacksAndMessages(null);
        questionText.setText("면접을 정리하고 있어요…");
        if (recording != null) recording.stop();   // Finalize 이벤트에서 openReport
        else openReport(null);
    }

    private void openReport(Uri videoUri) {
        Models.ReportRequest report = new Models.ReportRequest();
        report.persona = persona.name();
        report.mode = mode;
        report.turns = turns;
        report.metrics = metrics.build();

        Api.call(this, Api.get().event(Api.userId(this), new Models.Event("INTERVIEW_DONE", persona.name(), null)), p -> {});

        Intent i = new Intent(this, ReportActivity.class);
        i.putExtra(ReportActivity.EXTRA_REQUEST, new Gson().toJson(report));
        if (videoUri != null) i.putExtra(ReportActivity.EXTRA_VIDEO, videoUri.toString());
        startActivity(i);
        finish();
    }

    private void setInterviewerImage() {
        int id = getResources().getIdentifier("interviewer_" + persona.name().toLowerCase(Locale.US), "drawable", getPackageName());
        if (id != 0) ((ImageView) findViewById(R.id.interviewerImage)).setImageResource(id);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        if (tts != null) tts.shutdown();
        if (recognizer != null) recognizer.destroy();
        if (metrics != null) metrics.close();
        analysisExecutor.shutdown();
    }
}
