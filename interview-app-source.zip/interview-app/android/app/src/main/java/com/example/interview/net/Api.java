package com.example.interview.net;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.example.interview.BuildConfig;

import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class Api {
    private Api() {}

    private static ApiService service;

    public static synchronized ApiService get() {
        if (service == null) {
            // AI 응답은 수십 초 걸릴 수 있어서 타임아웃을 넉넉히
            OkHttpClient http = new OkHttpClient.Builder()
                    .readTimeout(120, TimeUnit.SECONDS)
                    .build();
            service = new Retrofit.Builder()
                    .baseUrl(BuildConfig.API_BASE)
                    .client(http)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                    .create(ApiService.class);
        }
        return service;
    }

    /** 로그인 대신 기기별 익명 ID (대충 버전) */
    public static String userId(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences("app", Context.MODE_PRIVATE);
        String id = p.getString("userId", null);
        if (id == null) {
            id = UUID.randomUUID().toString();
            p.edit().putString("userId", id).apply();
        }
        return id;
    }

    /** enqueue 를 짧게 쓰기 위한 헬퍼. 콜백은 메인 스레드에서 불린다. */
    public static <T> void call(Context ctx, Call<T> call, Consumer<T> onOk) {
        call.enqueue(new Callback<T>() {
            @Override
            public void onResponse(Call<T> c, Response<T> r) {
                if (r.isSuccessful() && r.body() != null) onOk.accept(r.body());
                else Toast.makeText(ctx, "요청 실패 (" + r.code() + ")", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<T> c, Throwable t) {
                Toast.makeText(ctx, "서버에 연결할 수 없어요", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
